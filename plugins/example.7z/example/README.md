# GLPi Example Plugin

## Introduction

This plugin implements a few basic glpi hooks.
Most of implemented features stands for example and are not
expected to provide fantastic functionality other than teaching.

## Documentation

This plugin is documented [here](https://github.com/pluginsGLPI/glpi-example-plugin/wiki),
It is the developer documentation for plugin contributors as of now.
You may change that link and provide documentation for your plugin,
if you totally create your plugin repository from the worktree of this one.

## Installation

```sh
cd /my/glpi/deployment/main/directory/plugins
git clone git@github.com:pluginsGLPI/glpi-example-plugin.git example
```
